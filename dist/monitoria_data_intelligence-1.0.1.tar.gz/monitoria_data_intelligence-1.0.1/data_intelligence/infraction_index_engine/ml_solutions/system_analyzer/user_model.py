def predict():
    return -1