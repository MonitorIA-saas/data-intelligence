def send_image():
    return -1