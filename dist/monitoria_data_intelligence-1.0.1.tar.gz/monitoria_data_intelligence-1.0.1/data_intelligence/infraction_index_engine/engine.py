def monitor():
    return -1 # Main func.