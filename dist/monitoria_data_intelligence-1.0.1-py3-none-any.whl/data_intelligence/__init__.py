def config(db_info, object_storage_info):
    return -1